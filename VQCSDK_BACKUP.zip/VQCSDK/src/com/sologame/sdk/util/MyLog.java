package com.sologame.sdk.util;

import android.util.Log;

public class MyLog {
	
	public static void log(String message) {
		Log.e("stk", message);
	}
}
